package sean_adi.Listeners;

import java.util.Map;

public interface TestUIEventsListener {

    void showTestFromUI();

    void addQuestionFromUI(String text, String rightAnswer, boolean isOpenQuestion, Map<String, Boolean> answers);

    void editQuestionFromUI(String oldText, String newText);

    void editAnswerFromUI(String oldText, String newText);

    void deleteAnswerFromUI(String questionValue, String answerValue);

    void createAutoTestFromUI(int numOfQuestions);

    void createManualTestFromUI(Map<String, Map<String, Boolean>> test);

    void showTestAsCopyFromUI();

    void exitFromUI();
}
