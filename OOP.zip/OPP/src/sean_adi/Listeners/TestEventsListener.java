package sean_adi.Listeners;

import java.util.ArrayList;
import java.util.Map;

public interface TestEventsListener {
    void showTestFromModelEvent();

    void deleteAnswerFromModelEvent(int answerIndex);

    void getNumOfQuestionsFromModelEvent(int numOfQuestions);

    void getQuestionsFromModelEvent(Map<String, ArrayList<String>> questions);

    void getAnswersFromModelEvent(ArrayList<String> answers);

    void getTestAsCopyFromModelEvent(String test);

    void getManualTestFromModelEvent(String test);

    void getAutoTestFromModelEvent(String test);
}
