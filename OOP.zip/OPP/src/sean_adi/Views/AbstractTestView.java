package sean_adi.Views;

import sean_adi.Listeners.TestUIEventsListener;

import java.util.ArrayList;
import java.util.Map;

public interface AbstractTestView {
    void registerListener(TestUIEventsListener listener);

    void getTest(String test);

    void deleteAnswerFromUI(int answerIndex);

    void getQuestions(Map<String, ArrayList<String>> questions);

    void getAnswers(ArrayList<String> answers);

    void getNumOfQuestions(int numOfQuestions);

    void getTestAsCopy(String test);

    void getManualTest(String test);

    void getAutoTest(String test);

    void getErrorMsg(String err);
}
