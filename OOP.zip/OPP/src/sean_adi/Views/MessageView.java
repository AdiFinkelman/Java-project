package sean_adi.Views;

import javafx.geometry.Insets;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class MessageView {
    private VBox vBox;

    public MessageView() {
        vBox = new VBox();
        vBox.setPadding(new Insets(10));
    }

    public void getMessage(String title, String massage) {
        vBox.getChildren().clear();

        //title
        Text txtTitle = new Text(title);
        txtTitle.setFont(Font.font(null, FontWeight.BOLD, 16));
        vBox.getChildren().add(txtTitle);

        //main text
        Text txt = new Text(massage);
        txt.setFont(Font.font(null, FontWeight.BOLD, 12));

        vBox.getChildren().add(txt);
    }

    public VBox getContent() {
        return vBox;
    }
}
