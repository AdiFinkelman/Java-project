package sean_adi.Views.Tabs;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import sean_adi.Listeners.TestUIEventsListener;

import java.util.ArrayList;
import java.util.Map;

public class EditQuestionView {
    private GridPane gpRoot;
    private ComboBox<String> comboBoxQuestions;

    public EditQuestionView(ArrayList<TestUIEventsListener> allListeners) {
        gpRoot = new GridPane();
        gpRoot.setPadding(new Insets(10));
        gpRoot.setHgap(15);
        gpRoot.setVgap(15);
        gpRoot.setAlignment(Pos.TOP_CENTER);

        Label lblText = new Label("Choose question:");
        lblText.setFont(Font.font(null, FontWeight.BOLD, 12));
        comboBoxQuestions = new ComboBox<String>();

        Label lblQuestion = new Label("Enter new question text:");
        lblQuestion.setFont(Font.font(null, FontWeight.BOLD, 12));
        TextField textFieldQuestion = new TextField();
        textFieldQuestion.setPromptText("new question text");

        Button btnEditQuestion = new Button("Edit");

        gpRoot.add(lblText, 0, 0);
        gpRoot.add(comboBoxQuestions, 0, 1);
        gpRoot.add(lblQuestion, 0, 2);
        gpRoot.add(textFieldQuestion, 1, 2);
        gpRoot.add(btnEditQuestion, 3, 2);

        btnEditQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                int index = comboBoxQuestions.getSelectionModel().getSelectedIndex();
                String questionValue = comboBoxQuestions.getSelectionModel().getSelectedItem();
                String text = textFieldQuestion.getText();

                for (TestUIEventsListener l : allListeners) {
                    l.editQuestionFromUI(questionValue, text);
                }
                comboBoxQuestions.getItems().set(index, text);
                textFieldQuestion.clear();
            }
        });
    }

    public void addQuestionToList(Map<String, ArrayList<String>> questions) {
        comboBoxQuestions.getItems().clear();

        for (String question : questions.keySet()) {
            comboBoxQuestions.getItems().add(question);
        }
        comboBoxQuestions.getSelectionModel().selectFirst();
    }

    public GridPane getContent() {
        return gpRoot;
    }
}
