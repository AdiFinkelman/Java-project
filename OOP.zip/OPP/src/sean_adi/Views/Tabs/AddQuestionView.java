package sean_adi.Views.Tabs;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import sean_adi.Listeners.TestUIEventsListener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class AddQuestionView {
    private GridPane gpRoot;
    private ListView<String> listViewAnswers;
    private boolean isOpenQuestion = false;
    private Map<String, Boolean> answers = new LinkedHashMap<>();

    public AddQuestionView(ArrayList<TestUIEventsListener> allListeners) {
        gpRoot = new GridPane();
        gpRoot.setPadding(new Insets(10));
        gpRoot.setHgap(15);
        gpRoot.setVgap(15);
        gpRoot.setAlignment(Pos.TOP_CENTER);

        Button btnAmericanQuestion = new Button("American Question");

        Button btnOpenQuestion = new Button("Open Question");

        gpRoot.add(btnAmericanQuestion, 1, 0);
        gpRoot.add(btnOpenQuestion, 2, 0);

        Label lblEnterText = new Label("Enter question text: ");
        lblEnterText.setFont(Font.font(null, FontWeight.BOLD, 12));
        TextField textFieldQuestion = new TextField();
        textFieldQuestion.setPromptText("Question");
        Button btnAddQuestion = new Button("Add Question");

        Label lblEnterAnswer = new Label("Enter answer Text: ");
        lblEnterAnswer.setFont(Font.font(null, FontWeight.BOLD, 12));
        TextField textFieldAnswer = new TextField();
        textFieldAnswer.setPromptText("Answer");
        Button btnAddAnswer = new Button("Add Answer");

        TextField textFieldRightAnswer = new TextField();
        textFieldRightAnswer.setPromptText("Enter right answer");

        Label lblAnswersText = new Label("Answers: ");
        lblAnswersText.setFont(Font.font(null, FontWeight.BOLD, 12));
        listViewAnswers = new ListView<String>();

        ComboBox<String> comboBoxIndicate = new ComboBox<String>();
        comboBoxIndicate.getItems().addAll("true", "false");
        comboBoxIndicate.getSelectionModel().selectLast();

        lblEnterAnswer.setVisible(false);
        btnAddAnswer.setVisible(false);
        textFieldAnswer.setVisible(false);
        lblAnswersText.setVisible(false);
        comboBoxIndicate.setVisible(false);
        listViewAnswers.setVisible(false);
        textFieldRightAnswer.setVisible(false);
        textFieldQuestion.setVisible(false);
        lblEnterText.setVisible(false);
        btnAddQuestion.setVisible(false);

        gpRoot.add(lblEnterText, 0, 2);
        gpRoot.add(textFieldQuestion, 1, 2);
        gpRoot.add(btnAddQuestion, 4, 5);
        gpRoot.add(lblEnterAnswer, 0, 3);
        gpRoot.add(textFieldAnswer, 1, 3);
        gpRoot.add(comboBoxIndicate, 3, 3);
        gpRoot.add(btnAddAnswer, 4, 3);
        gpRoot.add(textFieldRightAnswer, 3, 2);
        gpRoot.add(lblAnswersText, 0, 4);
        gpRoot.add(listViewAnswers, 0, 5);


        btnAddAnswer.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String answerText = textFieldAnswer.getText();
                listViewAnswers.getItems().add(answerText);
                answers.put(answerText, Boolean.valueOf(comboBoxIndicate.getValue()));

                textFieldAnswer.clear();
            }
        });

        btnAddQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String text = textFieldQuestion.getText();
                String rightAnswerText = textFieldRightAnswer.getText();

                for (TestUIEventsListener l : allListeners) {
                    l.addQuestionFromUI(text, rightAnswerText, isOpenQuestion, answers);
                }

                textFieldQuestion.clear();
                textFieldRightAnswer.clear();
                textFieldRightAnswer.clear();
                textFieldAnswer.clear();
                listViewAnswers.getItems().clear();
            }
        });

        btnOpenQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                lblEnterAnswer.setVisible(false);
                btnAddAnswer.setVisible(false);
                textFieldAnswer.setVisible(false);
                lblAnswersText.setVisible(false);
                comboBoxIndicate.setVisible(false);
                textFieldRightAnswer.setVisible(true);
                textFieldQuestion.setVisible(true);
                lblEnterText.setVisible(true);
                btnAddQuestion.setVisible(true);
                listViewAnswers.setVisible(false);
                isOpenQuestion = true;
            }
        });

        btnAmericanQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                lblEnterAnswer.setVisible(true);
                btnAddAnswer.setVisible(true);
                textFieldAnswer.setVisible(true);
                lblAnswersText.setVisible(true);
                comboBoxIndicate.setVisible(true);
                textFieldRightAnswer.setVisible(true);
                textFieldQuestion.setVisible(true);
                lblEnterText.setVisible(true);
                btnAddQuestion.setVisible(true);
                listViewAnswers.setVisible(true);
                isOpenQuestion = false;
            }
        });

        listViewAnswers.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    answers.remove(listViewAnswers.getSelectionModel().getSelectedItem());
                    listViewAnswers.getItems().remove(listViewAnswers.getSelectionModel().getSelectedItem());
                }
            }
        });
    }

    public GridPane getContent() {
        return gpRoot;
    }
}
