package sean_adi.Views.Tabs;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import sean_adi.Listeners.TestUIEventsListener;

import java.util.ArrayList;

public class EditAnswerView {
    private GridPane gpRoot;
    private ComboBox<String> comboBoxAnswers;

    public EditAnswerView(ArrayList<TestUIEventsListener> allListeners) {
        gpRoot = new GridPane();
        gpRoot.setPadding(new Insets(10));
        gpRoot.setHgap(15);
        gpRoot.setVgap(15);
        gpRoot.setAlignment(Pos.TOP_CENTER);

        Label lblText = new Label("Choose answer: ");
        lblText.setFont(Font.font(null, FontWeight.BOLD, 12));
        comboBoxAnswers = new ComboBox<String>();

        Label lblAnswer = new Label("Enter new answer text:");
        lblAnswer.setFont(Font.font(null, FontWeight.BOLD, 12));

        TextField textFieldAnswer = new TextField();
        textFieldAnswer.setPromptText("new answer text");

        Button btnEditAnswer = new Button("Edit");

        gpRoot.add(lblText, 0, 0);
        gpRoot.add(comboBoxAnswers, 0, 1);
        gpRoot.add(lblAnswer, 0, 2);
        gpRoot.add(textFieldAnswer, 1, 2);
        gpRoot.add(btnEditAnswer, 3, 2);

        btnEditAnswer.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                int answerIndex = comboBoxAnswers.getSelectionModel().getSelectedIndex();
                String answerValue = comboBoxAnswers.getSelectionModel().getSelectedItem();
                String text = textFieldAnswer.getText();

                for (TestUIEventsListener l : allListeners) {
                    l.editAnswerFromUI(answerValue, text);
                }
                comboBoxAnswers.getItems().set(answerIndex, text);
                textFieldAnswer.clear();
            }
        });

    }

    public void addAnswersToList(ArrayList<String> answers) {
        comboBoxAnswers.getItems().clear();
        comboBoxAnswers.getItems().addAll(answers);
        comboBoxAnswers.getSelectionModel().selectFirst();
    }

    public GridPane getContent() {
        return gpRoot;
    }
}
