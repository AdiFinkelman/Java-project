package sean_adi.Views.Tabs;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import sean_adi.Listeners.TestUIEventsListener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class ManualTestView {

    private GridPane gpRoot;
    private ComboBox<String> comboBoxQuestions;
    private ComboBox<String> comboBoxAnswers;
    Map<String, Map<String, Boolean>> manualTestList = new LinkedHashMap<>();
    Map<String, Boolean> questions = new LinkedHashMap<>();

    public ManualTestView(ArrayList<TestUIEventsListener> allListeners) {
        comboBoxQuestions = new ComboBox<String>();
        comboBoxAnswers = new ComboBox<String>();

        gpRoot = new GridPane();
        gpRoot.setPadding(new Insets(10));
        gpRoot.setHgap(15);
        gpRoot.setVgap(15);

        Label lblQuestions = new Label("Questions:");
        lblQuestions.setFont(Font.font(null, FontWeight.BOLD, 12));
        Label lblAnswers = new Label("Answers:");
        lblAnswers.setFont(Font.font(null, FontWeight.BOLD, 12));
        Button btnAddQuestion = new Button("Add question");
        Button btnAddAnswer = new Button("Add answer");

        Label lblOpenQuestion = new Label("You selected an open question. please select american question");
        lblOpenQuestion.setTextFill(Color.web("#FF0000"));
        lblOpenQuestion.setVisible(false);

        Label lblQuestionList = new Label("Your questions:");
        ListView<String> listViewQuestions = new ListView<String>();

        Label lblAnswersList = new Label("Your answers:");
        ListView<String> listViewAnswers = new ListView<String>();

        Label lblIndicateList = new Label("Is correct?");
        lblIndicateList.setFont(Font.font(null, FontWeight.BOLD, 12));
        ComboBox<String> comboBoxIndicate = new ComboBox<String>();
        comboBoxIndicate.getItems().addAll("true", "false");
        comboBoxIndicate.getSelectionModel().selectLast();

        lblAnswers.setVisible(false);
        comboBoxAnswers.setVisible(false);
        lblIndicateList.setVisible(false);
        comboBoxIndicate.setVisible(false);
        btnAddAnswer.setVisible(false);

        Button btnFinish = new Button("Show test");

        gpRoot.add(lblQuestions, 0, 0);
        gpRoot.add(comboBoxQuestions, 0, 1);
        gpRoot.add(lblAnswers, 1, 0);
        gpRoot.add(comboBoxAnswers, 1, 1);
        gpRoot.add(lblIndicateList, 2, 0);
        gpRoot.add(comboBoxIndicate, 2, 1);
        gpRoot.add(lblOpenQuestion, 1, 1);
        gpRoot.add(btnAddQuestion, 2, 2);
        gpRoot.add(btnAddAnswer, 3, 2);
        gpRoot.add(lblQuestionList, 0, 2);
        gpRoot.add(listViewQuestions, 0, 3);
        gpRoot.add(lblAnswersList, 1, 2);
        gpRoot.add(listViewAnswers, 1, 3);
        gpRoot.add(btnFinish, 3, 3);


        comboBoxQuestions.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                comboBoxAnswers.setVisible(false);
                lblAnswers.setVisible(false);
                lblIndicateList.setVisible(false);
                comboBoxIndicate.setVisible(false);
                btnAddAnswer.setVisible(false);

            }
        });

        btnAddQuestion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String questionValue = comboBoxQuestions.getValue();

                if (!manualTestList.containsKey(questionValue)) {
                    listViewQuestions.getItems().add(comboBoxQuestions.getValue());
                    if (questions.get(questionValue)) //American question
                        manualTestList.put(questionValue, new LinkedHashMap<>());
                    else //Open question
                        manualTestList.put(questionValue, null);
                }
            }
        });

        btnFinish.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                for (TestUIEventsListener l : allListeners) {
                    l.createManualTestFromUI(manualTestList);
                }
                manualTestList = new LinkedHashMap<>();
                listViewQuestions.getItems().clear();
                listViewAnswers.getItems().clear();
            }
        });

        btnAddAnswer.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String selectedQuestionValue = listViewQuestions.getSelectionModel().getSelectedItem();
                String answerValue = comboBoxAnswers.getValue();
                boolean indicate = Boolean.parseBoolean(comboBoxIndicate.getValue());

                Map<String, Boolean> answersList = manualTestList.get(selectedQuestionValue);

                if (!answersList.containsKey(answerValue)) {
                    listViewAnswers.getItems().add(comboBoxAnswers.getValue());
                    answersList.put(answerValue, indicate);
                }
            }
        });

        listViewQuestions.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                String selectedQuestionValue = listViewQuestions.getSelectionModel().getSelectedItem();

                if (mouseEvent.getClickCount() == 1) {
                    listViewAnswers.getItems().clear();

                    if (selectedQuestionValue != null) {
                        Map<String, Boolean> answersList = manualTestList.get(selectedQuestionValue);
                        if (answersList != null) {//American question
                            listViewAnswers.getItems().addAll(answersList.keySet());

                            comboBoxAnswers.setVisible(true);
                            lblAnswers.setVisible(true);
                            lblIndicateList.setVisible(true);
                            comboBoxIndicate.setVisible(true);
                            btnAddAnswer.setVisible(true);
                            lblOpenQuestion.setVisible(false);
                        } else {//Open question
                            comboBoxAnswers.setVisible(false);
                            lblAnswers.setVisible(false);
                            lblIndicateList.setVisible(false);
                            comboBoxIndicate.setVisible(false);
                            btnAddAnswer.setVisible(false);
                            lblOpenQuestion.setVisible(true);
                        }
                    }
                } else if (mouseEvent.getClickCount() == 2) {
                    listViewQuestions.getItems().remove(listViewQuestions.getSelectionModel().getSelectedItem());
                    manualTestList.remove(selectedQuestionValue);
                    listViewAnswers.getItems().clear();
                }
            }
        });

        listViewAnswers.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    String selectedQuestionValue = listViewQuestions.getSelectionModel().getSelectedItem();
                    String selectedAnswerValue = listViewAnswers.getSelectionModel().getSelectedItem();

                    Map<String, Boolean> answersList = manualTestList.get(selectedQuestionValue);

                    listViewAnswers.getItems().remove(selectedAnswerValue);
                    answersList.remove(selectedAnswerValue);
                }
            }
        });
    }

    public void addQuestionToList(Map<String, ArrayList<String>> questions) {
        comboBoxQuestions.getItems().clear();

        for (String question : questions.keySet()) {
            this.questions.put(question, questions.get(question) != null);

            comboBoxQuestions.getItems().add(question);
        }
        comboBoxQuestions.getSelectionModel().selectFirst();
    }

    public void addAnswersToList(ArrayList<String> answers) {
        comboBoxAnswers.getItems().clear();
        comboBoxAnswers.getItems().addAll(answers);
        comboBoxAnswers.getSelectionModel().selectFirst();
    }

    public GridPane getContent() {
        return gpRoot;
    }
}
