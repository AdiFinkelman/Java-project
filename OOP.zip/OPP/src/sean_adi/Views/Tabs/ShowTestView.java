package sean_adi.Views.Tabs;

import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class ShowTestView {
    private ScrollPane scrollPane = new ScrollPane();
    private VBox vBox = new VBox();

    public ShowTestView() {
        scrollPane.setContent(vBox);
        vBox.setPadding(new Insets(10));
    }

    public void setText(String text) {
        vBox.getChildren().clear();

        Text testText = new Text(text);
        testText.setFont(Font.font(16));

        vBox.getChildren().add(testText);
    }

    public ScrollPane getContent() {
        return scrollPane;
    }
}
