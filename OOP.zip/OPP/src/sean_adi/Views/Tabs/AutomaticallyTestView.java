package sean_adi.Views.Tabs;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import sean_adi.Listeners.TestUIEventsListener;

import java.util.ArrayList;

public class AutomaticallyTestView {
    private GridPane gpRoot;
    private BorderPane borderPane;
    private Spinner spinner;
    private VBox vBox;
    private ScrollPane scrollPane;

    public AutomaticallyTestView(ArrayList<TestUIEventsListener> allListeners) {
        gpRoot = new GridPane();
        borderPane = new BorderPane();
        gpRoot.setPadding(new Insets(10));
        gpRoot.setHgap(15);
        gpRoot.setVgap(15);
        gpRoot.setAlignment(Pos.TOP_CENTER);

        Label lblChooseText = new Label("Select num of question: ");
        lblChooseText.setFont(Font.font(null, FontWeight.BOLD, 12));

        spinner = new Spinner(1, 1, 1);
        Button btnShowTest = new Button("Show test");

        scrollPane = new ScrollPane();
        vBox = new VBox();
        scrollPane.setContent(vBox);
        scrollPane.setVisible(false);

        gpRoot.add(lblChooseText, 0, 0);
        gpRoot.add(spinner, 1, 0);
        gpRoot.add(btnShowTest, 2, 0);

        borderPane.setTop(gpRoot);
        borderPane.setCenter(scrollPane);

        btnShowTest.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                for (TestUIEventsListener l : allListeners) {
                    l.createAutoTestFromUI((Integer) spinner.getValue());
                }
            }
        });

    }

    public void setTestText(String test) {
        vBox.getChildren().clear();
        vBox.getChildren().add(new Text(test));
        scrollPane.setVisible(true);
    }

    public void updateNumOfQuestions(int numOfQuestions) {
        spinner = new Spinner(1, numOfQuestions, 1);
        gpRoot.add(spinner, 1, 0);
    }

    public BorderPane getContent() {
        return borderPane;
    }
}
