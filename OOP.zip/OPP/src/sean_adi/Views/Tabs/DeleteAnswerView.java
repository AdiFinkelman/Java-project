package sean_adi.Views.Tabs;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import sean_adi.Listeners.TestUIEventsListener;

import java.util.ArrayList;
import java.util.Map;

public class DeleteAnswerView {
    private GridPane gpRoot;
    private ComboBox<String> comboBoxQuestions;
    private ComboBox<String> comboBoxAnswers;
    private Map<String, ArrayList<String>> questions;

    public DeleteAnswerView(ArrayList<TestUIEventsListener> allListeners) {
        comboBoxQuestions = new ComboBox<String>();
        comboBoxAnswers = new ComboBox<String>();

        gpRoot = new GridPane();
        gpRoot.setPadding(new Insets(10));
        gpRoot.setHgap(15);
        gpRoot.setVgap(15);
        gpRoot.setAlignment(Pos.TOP_CENTER);

        Label lblQuestions = new Label("Questions:");
        lblQuestions.setFont(Font.font(null, FontWeight.BOLD, 12));
        Label lblAnswers = new Label("Answers:");
        lblAnswers.setFont(Font.font(null, FontWeight.BOLD, 12));
        Button btnDelete = new Button("Delete");

        Label lblOpenQuestion = new Label("You selected an open question. please select american question");
        lblOpenQuestion.setFont(Font.font(null, FontWeight.BOLD, 12));
        lblOpenQuestion.setTextFill(Color.web("#FF0000"));
        lblOpenQuestion.setVisible(false);

        gpRoot.add(lblQuestions, 0, 0);
        gpRoot.add(comboBoxQuestions, 0, 1);
        gpRoot.add(lblAnswers, 1, 0);
        gpRoot.add(comboBoxAnswers, 1, 1);
        gpRoot.add(lblOpenQuestion, 1, 1);
        gpRoot.add(btnDelete, 2, 2);


        comboBoxQuestions.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                comboBoxAnswers.getItems().clear();
                String questionValue = comboBoxQuestions.getSelectionModel().getSelectedItem();

                ArrayList<String> list = questions.get(questionValue);
                if (list != null) {
                    comboBoxAnswers.getItems().addAll(list);
                    lblOpenQuestion.setVisible(false);
                    btnDelete.setVisible(true);
                    comboBoxAnswers.setVisible(true);
                    lblAnswers.setVisible(true);
                } else {
                    lblOpenQuestion.setVisible(true);
                    btnDelete.setVisible(false);
                    comboBoxAnswers.setVisible(false);
                    lblAnswers.setVisible(false);
                }
            }
        });

        btnDelete.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String questionValue = comboBoxQuestions.getSelectionModel().getSelectedItem();
                String answerValue = comboBoxAnswers.getSelectionModel().getSelectedItem();

                for (TestUIEventsListener l : allListeners) {
                    l.deleteAnswerFromUI(questionValue, answerValue);
                }
            }
        });
    }

    public void deleteAnswerFromComboBox(int answerIndex) {
        comboBoxAnswers.getItems().remove(answerIndex);
    }

    public void addQuestionsToList(Map<String, ArrayList<String>> questions) {
        comboBoxQuestions.getItems().clear();

        this.questions = questions;

        for (String question : questions.keySet()) {
            comboBoxQuestions.getItems().add(question);
        }
        comboBoxQuestions.getSelectionModel().selectFirst();
    }

    public GridPane getContent() {
        return gpRoot;
    }
}
