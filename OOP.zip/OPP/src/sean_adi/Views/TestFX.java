package sean_adi.Views;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import sean_adi.Listeners.TestUIEventsListener;
import sean_adi.Views.Tabs.*;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Map;

public class TestFX implements AbstractTestView {
    private ArrayList<TestUIEventsListener> allListeners = new ArrayList<TestUIEventsListener>();
    private ShowTestView showTestView = new ShowTestView();
    private ShowTestView createTestAsCopyView = new ShowTestView();
    private EditQuestionView editQuestionView = new EditQuestionView(allListeners);
    private AddQuestionView addQuestionView = new AddQuestionView(allListeners);
    private EditAnswerView editAnswerView = new EditAnswerView(allListeners);
    private DeleteAnswerView deleteAnswerView = new DeleteAnswerView(allListeners);
    private AutomaticallyTestView automaticallyTestView = new AutomaticallyTestView(allListeners);
    private ManualTestView manualTestView = new ManualTestView(allListeners);
    private MessageView messageView = new MessageView();

    private Stage stageMessageView;

    private final String HELP_MESSAGE = "This machine is intended for build a mathematic test.\n" +
            "Please follow the next steps for build and changing your test:\n" +
            "1) Show test:\n" +
            "\tShowing the questions stock in the machine.\n" +
            "2) Add questions:\n" +
            "\tChoose questions type (multiple choise/open) then write your question and answer text.\n" +
            "3) Edit question: \n" +
            "\tPick a question stock and change question text.\n" +
            "4) Edit answer:\n" +
            "\tPick an answer from stock and change answer text.\n" +
            "5) Delete answer:\n" +
            "\tPick an answer from stock and click the button to delete it.\n" +
            "6) Manually test:\n" +
            "\tCreate a test by choose a question from stock by clicking the button \"add question\".\n\tIf you choose a multiple choise question click the question in the question added list and start adding answers.\n\tTo add answer choose an answer and indicate then click \"add answer\" button.\n" +
            "7) Automatically test:\n" +
            "\tAsk the machine to create an automatic test by choose number of questions and it will choose random questions from stock.\n" +
            "8) Copy test:\n" +
            "\tThis window will show you the last test created.\n" +
            "\n" +
            "To exit click the X button and the changes will be save.";

    public TestFX(Stage theStage) {
        theStage.setTitle("Exam");

        MenuBar menuBar = new MenuBar();
        Label lblMenu = new Label("Help");
        Menu menuHelp = new Menu(null, lblMenu);
        menuBar.getMenus().add(menuHelp);

        VBox vBox = new VBox(menuBar);

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.setBackground(new Background(new BackgroundFill(Color.web("#B3EEAE"), null, null)));

        Tab tabShowTest = new Tab("Show Test", showTestView.getContent());
        Tab tabShowTestAsCopy = new Tab("Create a test automatically", automaticallyTestView.getContent());

        tabPane.getTabs().add(tabShowTest);
        tabPane.getTabs().add(new Tab("Add question", addQuestionView.getContent()));
        tabPane.getTabs().add(new Tab("Edit question", editQuestionView.getContent()));
        tabPane.getTabs().add(new Tab("Edit answer", editAnswerView.getContent()));
        tabPane.getTabs().add(new Tab("Delete answer", deleteAnswerView.getContent()));
        tabPane.getTabs().add(new Tab("Create a test manually", manualTestView.getContent()));
        tabPane.getTabs().add(tabShowTestAsCopy);
        tabPane.getTabs().add(new Tab("Create copy test", createTestAsCopyView.getContent()));

        tabShowTest.setOnSelectionChanged(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                for (TestUIEventsListener l : allListeners)
                    l.showTestFromUI();
            }
        });

        tabShowTestAsCopy.setOnSelectionChanged(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                for (TestUIEventsListener l : allListeners)
                    l.showTestAsCopyFromUI();
            }
        });

        vBox.getChildren().add(tabPane);
        theStage.setScene(new Scene(vBox, 820, 520));
        theStage.show();

        //settings
        theStage.setResizable(false);

        stageMessageView = new Stage();
        stageMessageView.setTitle("Help");
        stageMessageView.setScene(new Scene(messageView.getContent(), 740, 520));
        messageView.getMessage("Welcome to test builder", HELP_MESSAGE);
        stageMessageView.show();

        theStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                for (TestUIEventsListener l : allListeners)
                    l.exitFromUI();
            }
        });

        lblMenu.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                messageView.getMessage("Welcome to test builder", HELP_MESSAGE);
                stageMessageView.show();
            }
        });
    }

    @Override
    public void registerListener(TestUIEventsListener listener) {
        allListeners.add(listener);
    }

    @Override
    public void getTest(String test) {
        showTestView.setText(test);
    }

    @Override
    public void deleteAnswerFromUI(int answerIndex) {
        deleteAnswerView.deleteAnswerFromComboBox(answerIndex);
    }

    @Override
    public void getQuestions(Map<String, ArrayList<String>> questions) {
        editQuestionView.addQuestionToList(questions);
        deleteAnswerView.addQuestionsToList(questions);
        manualTestView.addQuestionToList(questions);
    }

    @Override
    public void getAnswers(ArrayList<String> answers) {
        editAnswerView.addAnswersToList(answers);
        manualTestView.addAnswersToList(answers);
    }

    @Override
    public void getNumOfQuestions(int numOfQuestions) {
        automaticallyTestView.updateNumOfQuestions(numOfQuestions);
    }

    @Override
    public void getTestAsCopy(String test) {
        createTestAsCopyView.setText(test);
    }

    @Override
    public void getManualTest(String test) {
        stageMessageView.setTitle("Manual test");
        messageView.getMessage(null, test);
        stageMessageView.show();
    }

    @Override
    public void getAutoTest(String test) {
        automaticallyTestView.setTestText(test);
    }

    @Override
    public void getErrorMsg(String err) {
        JOptionPane.showMessageDialog(null, err, "ERROR", JOptionPane.ERROR_MESSAGE);
    }

}
