package sean_adi;

import javafx.application.Application;
import javafx.stage.Stage;
import sean_adi.Controller.TestController;
import sean_adi.Models.Questions.AmericanQuestion;
import sean_adi.Models.Questions.OpenQuestion;
import sean_adi.Models.Questions.Question;
import sean_adi.Models.Test;
import sean_adi.Views.AbstractTestView;
import sean_adi.Views.TestFX;

import java.util.ArrayList;


public class Program extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    private static ArrayList<Question> hardCoded() {
        ArrayList<Question> questions = new ArrayList<Question>();
        questions.add(new OpenQuestion("5+5?", "10"));
        questions.add(new OpenQuestion("3*5?", "15"));
        AmericanQuestion american0 = new AmericanQuestion("1.3+1.7?", "2");
        american0.addAnswer("2", true);
        american0.addAnswer("10212", false);
        american0.addAnswer("1546", false);
        questions.add(american0);
        AmericanQuestion american1 = new AmericanQuestion("4-5?", "-1");
        american1.addAnswer("-1", true);
        american1.addAnswer("10212", false);
        american1.addAnswer("1546", false);
        questions.add(american1);
        AmericanQuestion american2 = new AmericanQuestion("-3+2.9?", "-1.1");
        american2.addAnswer("0", false);
        american2.addAnswer("10212", false);
        american2.addAnswer("1546", false);
        questions.add(american2);

        return questions;
    }

    @Override
    public void start(Stage stage) throws Exception {
        //Hard Coded
//        Test test = new Test(hardCoded());

        Test test = new Test();
        AbstractTestView gui = new TestFX(stage);
        TestController controller = new TestController(test, gui);
    }
}
