package sean_adi.Controller;

import sean_adi.Exceptions.QuestionsArrayException;
import sean_adi.Exceptions.SelectionException;
import sean_adi.Listeners.TestEventsListener;
import sean_adi.Listeners.TestUIEventsListener;
import sean_adi.Models.Test;
import sean_adi.Views.AbstractTestView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public class TestController implements TestEventsListener, TestUIEventsListener {
    private Test testModel;
    private AbstractTestView testView;

    public TestController(Test model, AbstractTestView view) throws CloneNotSupportedException {
        testModel = model;
        testView = view;

        testView.registerListener(this);
        testModel.registerListener(this);

        showTestFromModelEvent();
    }

    @Override
    public void showTestFromModelEvent() {
        testView.getTest(testModel.toString());
    }

    @Override
    public void deleteAnswerFromModelEvent(int answerIndex) {
        testView.deleteAnswerFromUI(answerIndex);
    }

    @Override
    public void getNumOfQuestionsFromModelEvent(int numOfQuestions) {
        testView.getNumOfQuestions(numOfQuestions);
    }

    @Override
    public void getQuestionsFromModelEvent(Map<String, ArrayList<String>> questions) {
        testView.getQuestions(questions);
    }

    @Override
    public void getAnswersFromModelEvent(ArrayList<String> answers) {
        testView.getAnswers(answers);
    }

    @Override
    public void getTestAsCopyFromModelEvent(String test) {
        testView.getTestAsCopy(test);
    }

    @Override
    public void getManualTestFromModelEvent(String test) {
        testView.getManualTest(test);
    }

    @Override
    public void getAutoTestFromModelEvent(String test) {
        testView.getAutoTest(test);
    }

    @Override
    public void showTestFromUI() {
        testModel.fireShowTestEvent();
    }

    @Override
    public void addQuestionFromUI(String text, String rightAnswer, boolean isOpenQuestion, Map<String, Boolean> answers) {
        try {
            if (isOpenQuestion)
                testModel.addOpenQuestion(text, rightAnswer);
            else
                testModel.addAmericanQuestion(text, rightAnswer, answers);
        } catch (Exception e) {
            testView.getErrorMsg(e.getMessage());
        }
    }

    @Override
    public void editQuestionFromUI(String oldText, String newText) {
        try {
            testModel.setQuestionText(oldText, newText);
        } catch (SelectionException e) {
            testView.getErrorMsg(e.getMessage());
        }
    }

    @Override
    public void editAnswerFromUI(String oldText, String newText) {
        try {
            testModel.setAnswerText(oldText, newText);
        } catch (SelectionException e) {
            testView.getErrorMsg(e.getMessage());
        }

    }

    @Override
    public void deleteAnswerFromUI(String questionValue, String answerValue) {
        try {
            testModel.deleteAnswer(questionValue, answerValue);
        } catch (SelectionException | CloneNotSupportedException e) {
            testView.getErrorMsg(e.getMessage());
        }
    }

    @Override
    public void createAutoTestFromUI(int numOfQuestions) {
        try {
            testModel.startAutoTest(numOfQuestions);
        } catch (QuestionsArrayException | CloneNotSupportedException | FileNotFoundException e) {
            testView.getErrorMsg(e.getMessage());
        }
    }

    @Override
    public void createManualTestFromUI(Map<String, Map<String, Boolean>> test) {
        try {
            testModel.addManualQuestions(test);
        } catch (FileNotFoundException | CloneNotSupportedException e) {
            testView.getErrorMsg(e.getMessage());
        }
    }

    @Override
    public void showTestAsCopyFromUI() {
        try {
            testModel.fireGetLastTestAsCopyEvent();
        } catch (CloneNotSupportedException e) {
            testView.getErrorMsg(e.toString());
        }
    }

    @Override
    public void exitFromUI() {
        try {
            testModel.saveQuestionsToBinary();
        } catch (IOException e) {
            testView.getErrorMsg(e.toString());
        }
    }
}
