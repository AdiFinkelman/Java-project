package sean_adi.Comparators;

import sean_adi.Models.Questions.Question;

import java.util.Comparator;

public class CompareQuestionByAnswerLen implements Comparator<Question> {
    @Override
    public int compare(Question o1, Question o2) {
        if (o1.getAnswerLen() < o2.getAnswerLen()) return -1;
        else if (o1.getAnswerLen() > o2.getAnswerLen()) return 1;
        else return 0;
    }
}
