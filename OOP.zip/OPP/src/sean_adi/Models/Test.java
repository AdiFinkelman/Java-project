package sean_adi.Models;

import sean_adi.Comparators.CompareQuestionByAnswerLen;
import sean_adi.Exceptions.QuestionsArrayException;
import sean_adi.Exceptions.SelectionException;
import sean_adi.Listeners.TestEventsListener;
import sean_adi.Models.Questions.AmericanQuestion;
import sean_adi.Models.Questions.OpenQuestion;
import sean_adi.Models.Questions.Question;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class Test implements Cloneable {
    private ArrayList<Question> questions;
    private ArrayList<Question> manualQuestions;
    private ArrayList<Question> lastTest;
    private ArrayList<String> answers;
    private ArrayList<TestEventsListener> listeners;

    public static final String FILE_PATH = "tests\\";
    public static final String BINARY_FILE_NAME = "questions.dat";

    public Test() throws IOException, ClassNotFoundException {

        manualQuestions = new ArrayList<>();
        listeners = new ArrayList<TestEventsListener>();
        manual_answers_archive();

        questions = (new File(FILE_PATH + BINARY_FILE_NAME).exists()) ? readQuestionFromBinaryFile() : archive();
        Question.setIdCounter(getLastId() + 1);
        questions.sort(new CompareQuestionByAnswerLen());
        lastTest = new ArrayList<Question>(questions);
    }

    public Test(ArrayList<Question> questions) throws Exception {
        manualQuestions = new ArrayList<>();
        listeners = new ArrayList<TestEventsListener>();

        manual_answers_archive();
        this.questions = archive();
        this.questions.sort(new CompareQuestionByAnswerLen());
        for (int i = 0; i < questions.size(); i++)
            addQuestion(questions.get(i));
        lastTest = new ArrayList<Question>(questions);
    }

    public void registerListener(TestEventsListener listener) throws CloneNotSupportedException {
        listeners.add(listener);
        fireNumOfQuestionsEvent();
        fireGetQuestionsEvent();
        fireGetAnswersEvent();
        fireGetLastTestAsCopyEvent();
    }

    public ArrayList<String> getAnswers() {
        return answers;
    }

    public Map<String, ArrayList<String>> getQuestions() {
        Map<String, ArrayList<String>> q = new LinkedHashMap<>();

        for (Question question : questions) {
            q.put(question.getText(), question instanceof AmericanQuestion ? ((AmericanQuestion) question).getAnswersAsString() : null);
        }
        return q;
    }

    public boolean addManualQuestions(Map<String, Map<String, Boolean>> test) throws FileNotFoundException, CloneNotSupportedException {
        manualQuestions = new ArrayList<Question>();

        for (String question : test.keySet()) {
            int questionIndex = getIndexFromQuestionsListByString(question);

            if (questionIndex != -1) {
                String questionText = questions.get(questionIndex).getText();
                String correctAnswer = questions.get(questionIndex).getRightAnswer();

                //American question
                if (test.get(question) != null) {
                    AmericanQuestion americanQuestion = new AmericanQuestion(questionText, correctAnswer);

                    Map<String, Boolean> answersList = test.get(question);

                    for (String answer : answersList.keySet()) {
                        boolean indicate = answersList.get(answer);
                        americanQuestion.addAnswer(answer, indicate);
                    }
                    manualQuestions.add(americanQuestion);
                } else {//Open question
                    manualQuestions.add(new OpenQuestion(questionText, correctAnswer));
                }
            }
        }
        saveToTextFile(true, manualQuestions);
        saveToTextFile(false, manualQuestions);

        if (setLastTest(manualQuestions))
            fireGetLastTestAsCopyEvent();

        fireGetManualTestEvent();
        return true;
    }

    private int getIndexFromQuestionsListByString(String value) {
        for (int i = 0; i < questions.size(); i++) {
            if (questions.get(i).getText().equals(value))
                return i;
        }
        return -1;
    }

    private boolean addQuestion(Object q) throws Exception {
        if (questions.contains((Question) q))
            throw new Exception("Question exist");

        questions.add((Question) q);
        questions.sort(new CompareQuestionByAnswerLen());
        return true;
    }

    public boolean addOpenQuestion(String text, String answer) throws Exception {
        OpenQuestion openQuestion = new OpenQuestion(text, answer);
        boolean bool = addQuestion(openQuestion);
        fireShowTestEvent();
        fireNumOfQuestionsEvent();
        fireGetQuestionsEvent();
        return bool;
    }

    public boolean addAmericanQuestion(String text, String rightAnswer, Map<String, Boolean> answers) throws Exception {
        AmericanQuestion americanQuestion = new AmericanQuestion(text, rightAnswer);

        for (String answer : answers.keySet())
            americanQuestion.addAnswer(answer, answers.get(answer));

        boolean bool = addQuestion(americanQuestion);
        fireShowTestEvent();
        fireNumOfQuestionsEvent();
        fireGetQuestionsEvent();
        return bool;
    }

    public boolean setQuestionText(String oldText, String newText) throws SelectionException {
        int questionIndex = getIndexFromQuestionsListByString(oldText);

        if (questionIndex == -1)
            throw new SelectionException();

        boolean bool = questions.get(questionIndex).setText(newText);
        fireShowTestEvent();
        fireGetQuestionsEvent();
        return bool;
    }

    public boolean setAnswerText(String oldText, String newText) throws SelectionException {
        int index = getIndexFromAnswersByString(oldText);

        if (index == -1)
            throw new SelectionException();

        answers.set(index, newText);

        return true;
    }

    private int getIndexFromAnswersByString(String text) {
        for (int i = 0; i < answers.size(); i++) {
            if (answers.get(i).equals(text))
                return i;
        }
        return -1;
    }

    public boolean deleteAnswer(String questionValue, String answerValue) throws SelectionException, CloneNotSupportedException {
        int questionIndex = getIndexFromQuestionsListByString(questionValue);

        if (questionIndex == -1)
            throw new SelectionException();

        Question question = questions.get(questionIndex);

        if (question instanceof AmericanQuestion) {
            int answerIndex = ((AmericanQuestion) question).getAnswerIdByString(answerValue);

            if (answerIndex == -1)
                throw new SelectionException();

            boolean bool = ((AmericanQuestion) question).deleteAnswer(answerIndex);
            fireDeleteAnswerEvent(answerIndex);
            fireShowTestEvent();
            fireGetLastTestAsCopyEvent();
            return bool;
        } else
            throw new SelectionException();
    }

    private void fireDeleteAnswerEvent(int answerIndex) {
        for (TestEventsListener l : listeners) {
            l.deleteAnswerFromModelEvent(answerIndex);
        }
    }

    public void fireShowTestEvent() {
        for (TestEventsListener l : listeners) {
            l.showTestFromModelEvent();
        }
    }

    private void fireNumOfQuestionsEvent() {
        for (TestEventsListener l : listeners) {
            l.getNumOfQuestionsFromModelEvent(questions.size());
        }
    }

    private void fireGetQuestionsEvent() {
        for (TestEventsListener l : listeners) {
            l.getQuestionsFromModelEvent(getQuestions());
        }
    }

    private void fireGetAnswersEvent() {
        for (TestEventsListener l : listeners) {
            l.getAnswersFromModelEvent(getAnswers());
        }
    }

    public void fireGetLastTestAsCopyEvent() throws CloneNotSupportedException {
        for (TestEventsListener l : listeners) {
            l.getTestAsCopyFromModelEvent(clone().printLastTest());
        }
    }

    private void fireGetManualTestEvent() {
        for (TestEventsListener l : listeners) {
            l.getManualTestFromModelEvent(printManualQuestions(manualQuestions));
        }
    }

    private void fireGetAutoTestEvent(String test) {
        for (TestEventsListener l : listeners) {
            l.getAutoTestFromModelEvent(test);
        }
    }

    private ArrayList<Question> archive() {
        ArrayList<Question> questions = new ArrayList<Question>();
        ArrayList<Question> manualQuestions = manual_question_archive();
        ArrayList<String> answers = getAnswers();

        for (int i = 0; i < manualQuestions.size(); i++) {
            questions.add(manualQuestions.get(i));
            if (questions.get(i) instanceof AmericanQuestion) {
                Collections.shuffle(answers);

                for (int j = 0; j < 4; j++) {
                    AmericanQuestion americanQuestion = ((AmericanQuestion) questions.get(i));
                    boolean isCorrect = americanQuestion.isRightAnswer(answers.get(j));
                    americanQuestion.addAnswer(answers.get(j), isCorrect);
                }
            }
        }
        return questions;
    }

    private void manual_answers_archive() {
        answers = new ArrayList<String>(List.of("1", "-1", "1.1", "-1.1", "-1.01", "1.18", "-15", "13", "pizza", "student", "-95151", "453646", "12121"));
    }

    private ArrayList<Question> manual_question_archive() {
        ArrayList<Question> questionsArchive = new ArrayList<Question>();

        //open questions
        questionsArchive.add(new OpenQuestion("1+1?", "2"));
        questionsArchive.add(new OpenQuestion("0*5?", "0"));
        questionsArchive.add(new OpenQuestion("2+5?", "7"));
        questionsArchive.add(new OpenQuestion("20-3?", "17"));
        questionsArchive.add(new OpenQuestion("17-18?", "-1"));

        //american questions
        AmericanQuestion american0 = new AmericanQuestion("0.3+0.7?", "1");
        questionsArchive.add(american0);
        AmericanQuestion american1 = new AmericanQuestion("2-3?", "-1");
        questionsArchive.add(american1);
        AmericanQuestion american2 = new AmericanQuestion("-2+0.9?", "-1.1");
        questionsArchive.add(american2);
        AmericanQuestion american3 = new AmericanQuestion("5+9?", "There is no correct answer");
        questionsArchive.add(american3);
        AmericanQuestion american4 = new AmericanQuestion("4+9?", "13");
        questionsArchive.add(american4);

        return questionsArchive;
    }

    public void saveQuestionsToBinary() throws IOException {
        ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(FILE_PATH + BINARY_FILE_NAME));
        outputStream.writeObject(questions);
        outputStream.close();
    }

    private ArrayList<Question> readQuestionFromBinaryFile() throws IOException, ClassNotFoundException {
        ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(FILE_PATH + BINARY_FILE_NAME));
        return (ArrayList<Question>) inputStream.readObject();
    }

    public ArrayList<Question> getAutoFromArchive(int numOfQuestions) {
        ArrayList<Question> archive = new ArrayList<>(questions);
        ArrayList<Question> newArchive = new ArrayList<>();
        Collections.shuffle(archive);

        for (int i = 0; i < numOfQuestions; i++)
            newArchive.add(archive.get(i));

        return newArchive;
    }

    public void startAutoTest(int numOfQuestions) throws QuestionsArrayException, CloneNotSupportedException, FileNotFoundException {
        if (numOfQuestions > questions.size() || numOfQuestions < 0)
            throw new QuestionsArrayException(questions.size());

        ArrayList<Question> questions = getAutoFromArchive(numOfQuestions);
        StringBuffer sb = new StringBuffer();

        sb.append(printQuestionWithoutAnswers(questions));
        sb.append("\n");
        sb.append(printManualQuestions(questions));

        setLastTest(questions);

        saveToTextFile(true, questions);
        saveToTextFile(false, questions);
        fireGetAutoTestEvent(sb.toString());
        fireGetLastTestAsCopyEvent();
    }

    public void saveToTextFile(boolean withAnswers, ArrayList<Question> list) throws FileNotFoundException {
        PrintWriter pw = null;

        LocalDate date = LocalDate.now();
        int day = date.getDayOfMonth();
        int month = date.getMonthValue();
        int year = date.getYear();

        String dateFormat = year + "_" + String.format("%02d", month) + "_" + String.format("%02d", day);

        if (withAnswers) {
            File f = new File(FILE_PATH + "exam_" + dateFormat + ".txt");
            pw = new PrintWriter(f);
            pw.write(printQuestionWithoutAnswers(list));
        } else {
            File f = new File(FILE_PATH + "solution_" + dateFormat + ".txt");
            pw = new PrintWriter(f);
            pw.write(printManualQuestions(list));
        }
        pw.close();
    }

    public String printQuestionWithoutAnswers(ArrayList<Question> list) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < list.size(); i++) {
            sb.append((i + 1) + ") " + list.get(i).getText() + "\n");
            if (list.get(i) instanceof AmericanQuestion)
                sb.append(((AmericanQuestion) list.get(i)).getAnswersByString(false) + "\n");
        }
        return sb.toString();
    }

    public String printManualQuestions(ArrayList<Question> list) {
        StringBuffer sb = new StringBuffer();
        for (int j = 0; j < list.size(); j++)
            sb.append((j + 1) + ") " + list.get(j) + "\n");
        return sb.toString();
    }

    private int getLastId() {
        int lastID = 0;

        for (Question q : questions) {
            int id = q.getId();
            lastID = id > lastID ? id : lastID;
        }
        return lastID;
    }

    public boolean setLastTest(ArrayList<Question> list) {
        lastTest = list;
        return true;
    }

    public String printLastTest() {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < lastTest.size(); i++) {
            sb.append(lastTest.get(i) + "\n");
        }
        return sb.toString();
    }

    @Override
    public Test clone() throws CloneNotSupportedException {
        Test temp = (Test) super.clone();
        temp.lastTest.clone();
        return temp;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Test))
            return false;

        return Objects.equals(this, o);
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < questions.size(); i++) {
            sb.append(questions.get(i) + "\n");
        }
        return sb.toString();
    }
}
