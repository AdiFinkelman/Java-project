package sean_adi.Models.Questions;

import java.io.Serializable;

public class Answer implements Serializable, Cloneable {
    private String text;
    private boolean isCorrect;

    public Answer(String text, boolean isCorrect) {
        this.text = text;
        this.isCorrect = isCorrect;
    }

    public String getText() {
        return text;
    }

    public boolean setIsCorrect(boolean isCorrect) {
        this.isCorrect = isCorrect;
        return true;
    }

    public boolean isCorrect() {
        return isCorrect;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Answer))
            return false;
        return ((Answer) obj).getText().equals(this.text);
    }

    @Override
    public Answer clone() throws CloneNotSupportedException {
        return (Answer) super.clone();
    }

    @Override
    public String toString() {
        return text;
    }
}
