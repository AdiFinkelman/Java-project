package sean_adi.Models.Questions;

import sean_adi.List.SetList;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class AmericanQuestion extends Question implements Serializable, Cloneable {
    private SetList<Answer> answers;

    private int numOfRightAnswers;

    public AmericanQuestion(String text, String right_answer) {
        super(text, right_answer);
        answers = new SetList<Answer>();
        addAnswer("There is no correct answer", true);
        currentRightAnswer = "There is no correct answer";
        addAnswer("There is more then one correct answer", false);
    }

    public ArrayList<String> getAnswersAsString() {

        ArrayList<String> answersList = new ArrayList<>();

        for (int i = 0; i < answers.size(); i++)
            answersList.add(answers.get(i).getText());

        return answersList;
    }

    public String getAnswersByString(boolean withAnswer) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < answers.size(); i++) {
            sb.append("\t" + (i + 1) + ")" + answers.get(i).getText() + (withAnswer ? (currentRightAnswer(answers.get(i).getText()) ? " V" : " X") : "") + (i == answers.size() - 1 ? "" : "\n"));
        }
        return sb.toString();
    }

    @Override
    protected void countChar(String answer) {
        answerLen += answer.length();
    }

    public boolean addAnswer(String text, boolean isCorrect) {
        countChar(text);

        if (isCorrect) {
            if (answers.size() > 0) {
                if (!answers.get(0).isCorrect())
                    numOfRightAnswers++;
                else
                    answers.get(0).setIsCorrect(false);
                if (numOfRightAnswers > 0) {
                    answers.get(1).setIsCorrect(true);
                    currentRightAnswer = "There is more then one correct answer";
                } else {
                    currentRightAnswer = text;
                }
            }
        }
        return answers.add(new Answer(text, isCorrect));
    }

    public boolean deleteAnswer(int index) {
        return answers.remove(answers.get(index));
    }

    public int getAnswerIdByString(String value) {
        for (int i = 0; i < answers.size(); i++) {
            if (answers.get(i).getText().equals(value))
                return i;
        }
        return -1;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof AmericanQuestion) && o instanceof OpenQuestion)
            return false;
        else if (!(o instanceof AmericanQuestion))
            return false;
        else if (o instanceof AmericanQuestion)
            return Objects.equals(((AmericanQuestion) o).getText(), this.getText());

        return Objects.equals(o, this);
    }

    @Override
    public AmericanQuestion clone() throws CloneNotSupportedException {
        return (AmericanQuestion) super.clone();
    }

    @Override
    public String toString() {
        return super.toString() + "\nAnswers options:\n" + getAnswersByString(true);
    }
}
