package sean_adi.Models.Questions;

import java.io.Serializable;
import java.util.Objects;

public abstract class Question implements Serializable, Cloneable {
    protected int id;
    private static int id_counter;

    protected String text;
    protected String rightAnswer;
    protected String currentRightAnswer;
    protected int answerLen;

    public Question(String text, String currentRightAnswer) {
        this.text = text;
        this.rightAnswer = currentRightAnswer;
        this.currentRightAnswer = currentRightAnswer;
        id = id_counter++;
    }

    public final String getText() {
        return this.text;
    }

    public final boolean setText(String text) {
        this.text = text;
        return true;
    }

    public final String getRightAnswer() {
        return this.rightAnswer;
    }

    public final boolean isRightAnswer(String answer) {
        return this.rightAnswer.equals(answer);
    }

    public final boolean currentRightAnswer(String answer) {
        return this.currentRightAnswer.equals(answer);
    }

    protected abstract void countChar(String s);

    public final int getAnswerLen() {
        return this.answerLen;
    }

    public final int getId() {
        return this.id;
    }

    public static void setIdCounter(int id) {
        id_counter = id;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof OpenQuestion))
            return false;
        else if (o instanceof AmericanQuestion)
            return Objects.equals(o, this);

        return Objects.equals(this.text, ((OpenQuestion) o).text);
    }

    @Override
    public Question clone() throws CloneNotSupportedException {
        return (Question) super.clone();
    }

    @Override
    public String toString() {
        return "Question: " + text + " - the right answer is: " + currentRightAnswer;
    }
}
