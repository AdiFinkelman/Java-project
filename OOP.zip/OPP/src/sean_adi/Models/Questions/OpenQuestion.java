package sean_adi.Models.Questions;

import java.io.Serializable;
import java.util.Objects;

public class OpenQuestion extends Question implements Serializable, Cloneable {
    public OpenQuestion(String text, String rightAnswer) {
        super(text, rightAnswer);
        countChar(rightAnswer);
    }

    @Override
    protected void countChar(String answer) {
        answerLen = answer.length();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof OpenQuestion))
            return false;
        else if (o instanceof AmericanQuestion)
            return Objects.equals(o, this);

        return Objects.equals(this.text, ((OpenQuestion) o).text);
    }

    @Override
    public OpenQuestion clone() throws CloneNotSupportedException {
        return (OpenQuestion) super.clone();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
