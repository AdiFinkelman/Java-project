package sean_adi.Exceptions;

public class SelectionException extends Exception {
    public SelectionException() {
        super("Wrong selection. Please enter the right selections.");
    }
}
