package sean_adi.Exceptions;

public class QuestionsArrayException extends Exception {
    public QuestionsArrayException(int i) {
        super("You can choose " + i + " question. Please select the right num of questions");
    }
}
