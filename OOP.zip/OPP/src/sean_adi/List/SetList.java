package sean_adi.List;

import java.io.Serializable;
import java.util.Arrays;

public class SetList<T> implements Serializable {
    private T[] arr;
    private int size = 0;

    public SetList() {
        arr = (T[]) new Object[1];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return arr.length == 1 && arr[1] == null;
    }

    public boolean contains(T type) throws RuntimeException {
        for (int i = 0; i < size; i++) {
            if (arr[i] != null && arr[i].equals(type))
                return true;
        }
        return false;
    }

    public boolean add(T type) {
        if (contains(type))
            return false;

        if (arr[arr.length - 1] != null)
            setBigger();

        arr[size++] = type;
        return true;
    }

    public T get(int index) {
        return arr[index];
    }

    public boolean remove(T type) {
        if (!contains(type))
            return false;

        for (int i = getLocation(type); i < size - 1; i++)
            arr[i] = arr[i + 1];

        arr[size - 1] = null;
        size--;

        return true;
    }

    private void setBigger() {
        arr = Arrays.copyOf(arr, arr.length * 2);
    }

    private int getLocation(T type) {
        if (!contains(type))
            return -1;
        for (int i = 0; i < size; i++) {
            if (arr[i].equals(type))
                return i;
        }
        return -1;
    }

    public void clear() {
        arr = (T[]) new Object[1];
    }
}
