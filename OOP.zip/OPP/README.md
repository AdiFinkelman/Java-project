#exercise: 3
name: Sean Pinchevsky
id: 318647617
name: Adi Finkelman
id: 313741340

Run first time the project to save the questions to the binary file and then the project will automatically load the
question from the binary file.